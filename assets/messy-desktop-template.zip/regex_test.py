#!/usr/bin/env python3
"""Testing regex patterns because I can never remember the syntax."""
import re

# Email validation (basic)
email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

test_emails = [
    'user@example.com',
    'first.last@company.co.uk',
    'not-an-email',
    '@missing.com',
    'spaces in@email.com',
    'valid+tag@gmail.com',
]

print("Email validation:")
for email in test_emails:
    match = re.match(email_pattern, email)
    print(f"  {email:30s} -> {'VALID' if match else 'INVALID'}")

# Phone number extraction
phone_pattern = r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'
text = "Call me at (555) 123-4567 or 555.987.6543 or 555-111-2222"
phones = re.findall(phone_pattern, text)
print(f"\nPhone numbers found: {phones}")

# URL extraction
url_pattern = r'https?://[\w.-]+(?:\.[\w]+)+(?:/[\w.-]*)*/?'
text2 = "Visit https://example.com/page or http://test.org/path/to/thing"
urls = re.findall(url_pattern, text2)
print(f"\nURLs found: {urls}")

# IP address (v4)
ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
log = "Request from 192.168.1.1 forwarded to 10.0.0.5 via 255.255.255.0"
ips = re.findall(ip_pattern, log)
print(f"\nIP addresses: {ips}")
