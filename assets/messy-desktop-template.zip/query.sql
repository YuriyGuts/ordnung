-- Useful queries for debugging
-- Last updated: Jan 2026

-- Find users who signed up but never completed onboarding
SELECT u.id, u.email, u.created_at
FROM users u
LEFT JOIN onboarding_steps os ON u.id = os.user_id
WHERE os.id IS NULL
  AND u.created_at > '2025-01-01'
ORDER BY u.created_at DESC;

-- Monthly active users
SELECT
  DATE_TRUNC('month', last_login) AS month,
  COUNT(DISTINCT user_id) AS mau
FROM sessions
WHERE last_login >= NOW() - INTERVAL '12 months'
GROUP BY 1
ORDER BY 1;

-- Find duplicate emails (case-insensitive)
SELECT LOWER(email) AS email, COUNT(*) AS cnt
FROM users
GROUP BY LOWER(email)
HAVING COUNT(*) > 1
ORDER BY cnt DESC;

-- Slow queries log
-- EXPLAIN ANALYZE
-- SELECT * FROM orders o
-- JOIN order_items oi ON o.id = oi.order_id
-- JOIN products p ON oi.product_id = p.id
-- WHERE o.status = 'pending'
--   AND o.created_at > NOW() - INTERVAL '7 days';

-- TODO: write a query to find orphaned records
-- TODO: check if we need an index on orders.status
