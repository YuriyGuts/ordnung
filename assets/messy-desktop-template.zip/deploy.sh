#!/bin/bash
# Deployment script - USE WITH CAUTION
# Last updated: Dec 2025

set -euo pipefail

ENVIRONMENT="${1:-staging}"
BRANCH="${2:-main}"

echo "==================================="
echo "Deploying to: $ENVIRONMENT"
echo "Branch: $BRANCH"
echo "==================================="

if [ "$ENVIRONMENT" = "production" ]; then
    echo "⚠️  PRODUCTION DEPLOYMENT"
    read -p "Are you sure? (yes/no): " confirm
    if [ "$confirm" != "yes" ]; then
        echo "Aborted."
        exit 1
    fi
fi

echo "Step 1: Pulling latest code..."
git checkout "$BRANCH"
git pull origin "$BRANCH"

echo "Step 2: Installing dependencies..."
pip install -r requirements.txt

echo "Step 3: Running migrations..."
python manage.py migrate

echo "Step 4: Collecting static files..."
python manage.py collectstatic --noinput

echo "Step 5: Restarting services..."
sudo systemctl restart myapp
sudo systemctl restart nginx

echo "Step 6: Health check..."
sleep 5
curl -sf http://localhost:8080/health || {
    echo "Health check failed! Rolling back..."
    # TODO: implement rollback
    exit 1
}

echo "==================================="
echo "Deployment complete!"
echo "==================================="
