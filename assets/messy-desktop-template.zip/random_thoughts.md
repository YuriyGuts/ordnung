# Random Thoughts

## App Ideas
- An app that tells you what to cook based on what's in your fridge
  - probably already exists. check App Store
- Spotify but for podcasts... wait that's just Spotify now
- A calendar that automatically blocks "focus time"

## Things I Learned Today
- Apparently `git rebase -i` can squash commits. Where has this been all my life
- Python 3.12 has better error messages
- You can `cmd+shift+.` to show hidden files on Mac

## Quotes
> "The best time to plant a tree was 20 years ago. The second best time is now."

> "It works on my machine" — every developer ever

## Weekend Plans
- [ ] Try that new ramen place on 5th
- [ ] Finish reading that book (which book?? the one on the nightstand)
- [ ] Maybe go for a hike if weather is good
- [ ] Laundry (for real this time)
