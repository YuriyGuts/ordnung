#!/usr/bin/env python3
"""Script to fix the data migration issue.

TODO: This is half-finished. Need to handle edge cases.
"""
import csv
import sys

def load_data(filepath):
    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)

def fix_dates(records):
    """Convert dates from MM/DD/YYYY to YYYY-MM-DD."""
    fixed = []
    for record in records:
        date = record.get('date', '')
        if '/' in date:
            parts = date.split('/')
            if len(parts) == 3:
                record['date'] = f"{parts[2]}-{parts[0]:>02}-{parts[1]:>02}"
        fixed.append(record)
    return fixed

def fix_emails(records):
    """Lowercase all email addresses."""
    for record in records:
        if 'email' in record:
            record['email'] = record['email'].strip().lower()
    return records

# TODO: also need to deduplicate
# TODO: handle records with missing IDs
# TODO: what about unicode in names??

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python fix_thing.py <input.csv>")
        sys.exit(1)

    data = load_data(sys.argv[1])
    data = fix_dates(data)
    data = fix_emails(data)

    # write output... somewhere
    # writer = csv.DictWriter(sys.stdout, fieldnames=data[0].keys())
    # writer.writeheader()
    # writer.writerows(data)
    print(f"Processed {len(data)} records")
    print("TODO: actually write the output file lol")
