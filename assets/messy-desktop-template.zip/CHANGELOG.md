# Changelog

## [Unreleased]
- Working on search feature
- Bug fix for date parsing

## [1.2.0] - 2026-01-10
### Added
- User profile page
- Export data as CSV
### Fixed
- Login redirect loop
- Timezone display issues

## [1.1.0] - 2025-12-15
### Added
- Dashboard with charts
- Email notifications (basic)
### Changed
- Upgraded to Python 3.12
- Switched from SQLite to PostgreSQL

## [1.0.0] - 2025-11-01
### Added
- Initial release
- User registration and login
- Basic CRUD for projects
- REST API
