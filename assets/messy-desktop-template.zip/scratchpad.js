// Scratchpad - random experiments
// don't judge this code

// flatten an array (why isn't this built in?? oh wait it is now)
const flatten = (arr) => arr.reduce((acc, val) =>
  Array.isArray(val) ? acc.concat(flatten(val)) : acc.concat(val), []);

// debounce function from that blog post
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// testing fetch with async/await
async function fetchUsers() {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/users');
    const users = await response.json();
    console.log(users.map(u => u.name));
  } catch (err) {
    console.error('oops:', err);
  }
}

// that weird fizzbuzz one-liner someone showed me
const fizzbuzz = n => Array.from({length: n}, (_, i) => ++i)
  .map(n => (n % 3 ? '' : 'Fizz') + (n % 5 ? '' : 'Buzz') || n);

// TODO: figure out why the websocket thing keeps disconnecting
// TODO: try out that new Temporal API for dates

console.log(fizzbuzz(15));
console.log(flatten([1, [2, [3, [4]], 5]]));
